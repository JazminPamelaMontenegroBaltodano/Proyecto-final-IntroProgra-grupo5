package proyectofinal;

import javax.swing.JOptionPane;

public class Rutinas {

    class Deportista {

        private int id;
        private String nombre;
        private String apellidos;
        private String ciudad;
        private String direccion;
        private int telefono;
        private String correoElectronico;
        private boolean estado;

        public Deportista() {
            this.id = 0;
            this.nombre = "";
            this.apellidos = "";
            this.ciudad = "";
            this.direccion = "";
            this.telefono = 0;
            this.correoElectronico = "";
            this.estado = true;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public String getApellidos() {
            return apellidos;
        }

        public void setApellidos(String apellidos) {
            this.apellidos = apellidos;
        }

        public String getCiudad() {
            return ciudad;
        }

        public void setCiudad(String ciudad) {
            this.ciudad = ciudad;
        }

        public String getDireccion() {
            return direccion;
        }

        public void setDireccion(String direccion) {
            this.direccion = direccion;
        }

        public int getTelefono() {
            return telefono;
        }

        public void setTelefono(int telefono) {
            this.telefono = telefono;
        }

        public String getCorreoElectronico() {
            return correoElectronico;
        }

        public void setCorreoElectronico(String correoElectronico) {
            this.correoElectronico = correoElectronico;
        }

        public boolean isEstado() {
            return estado;
        }

        public void setEstado(boolean estado) {
            this.estado = estado;
        }

    }

    public class PadreFamilia {

        private String nombre;
        private String apellidos;
        private String nombreNinoACargo;
        private String ciudad;
        private String direccion;
        private int telefono;
        private String correoElectronico;
        private boolean estado;

        public PadreFamilia() {
            this.nombre = "";
            this.apellidos = "";
            this.nombreNinoACargo = "";
            this.ciudad = "";
            this.direccion = "";
            this.telefono = 0;
            this.correoElectronico = "";
            this.estado = true;
        }

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public String getApellidos() {
            return apellidos;
        }

        public void setApellidos(String apellidos) {
            this.apellidos = apellidos;
        }

        public String getNombreNinoACargo() {
            return nombreNinoACargo;
        }

        public void setNombreNinoACargo(String nombreNinoACargo) {
            this.nombreNinoACargo = nombreNinoACargo;
        }

        public String getCiudad() {
            return ciudad;
        }

        public void setCiudad(String ciudad) {
            this.ciudad = ciudad;
        }

        public String getDireccion() {
            return direccion;
        }

        public void setDireccion(String direccion) {
            this.direccion = direccion;
        }

        public int getTelefono() {
            return telefono;
        }

        public void setTelefono(int telefono) {
            this.telefono = telefono;
        }

        public String getCorreoElectronico() {
            return correoElectronico;
        }

        public void setCorreoElectronico(String correoElectronico) {
            this.correoElectronico = correoElectronico;
        }

        public boolean isEstado() {
            return estado;
        }

        public void setEstado(boolean estado) {
            this.estado = estado;
        }

    }

    public class Deporte {

        private int id;
        private String nombre;
        private String caracteristicas;
        private boolean estado;

        public Deporte() {
            this.id = 0;
            this.nombre = "";
            this.caracteristicas = "";
            this.estado = true;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public String getCaracteristicas() {
            return caracteristicas;
        }

        public void setCaracteristicas(String caracteristicas) {
            this.caracteristicas = caracteristicas;
        }

        public boolean isEstado() {
            return estado;
        }

        public void setEstado(boolean estado) {
            this.estado = estado;
        }

    }

    public class Rutina {

        private int id;
        private String descripcion;
        private int deporteId;
        private int tiempoDuracion;
        private boolean estado;

        public Rutina() {
            this.id = 0;
            this.descripcion = "";
            this.deporteId = 0;
            this.tiempoDuracion = 0;
            this.estado = true;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getDescripcion() {
            return descripcion;
        }

        public void setDescripcion(String descripcion) {
            this.descripcion = descripcion;
        }

        public int getDeporteId() {
            return deporteId;
        }

        public void setDeporteId(int deporteId) {
            this.deporteId = deporteId;
        }

        public int getTiempoDuracion() {
            return tiempoDuracion;
        }

        public void setTiempoDuracion(int tiempoDuracion) {
            this.tiempoDuracion = tiempoDuracion;
        }

        public boolean isEstado() {
            return estado;
        }

        public void setEstado(boolean estado) {
            this.estado = estado;
        }

    }

    public class DeportesYRutinas {

        Deportista[] deportistas;
        PadreFamilia[] padresFamilia;
        Deporte[] deportes;
        Rutina[] rutinas;

        // Constructor
        public DeportesYRutinas(int tam) {
            deportistas = new Deportista[tam];
            padresFamilia = new PadreFamilia[tam];
            deportes = new Deporte[tam];
            rutinas = new Rutina[tam];
        }
    }

    public void agregarRutina(String descripcion, int deporteId, int tiempoDuracion) {
        boolean deporteExiste = false;
        boolean rutinaExiste = false;

        // Verificar si el deporte existe
        for (Deporte d : deportes) {
            if (d.getId() == deporteId) {
                deporteExiste = true;
                break;
            }
        }

        // Verificar si la rutina ya estÃ¡ registrada
        for (Rutina r : rutinas) {
            if (r.getDescripcion().equals(descripcion) && r.getDeporteId() == deporteId) {
                rutinaExiste = true;
                break;
            }
        }

        // Agregar la rutina si cumple con las condiciones
        if (deporteExiste && !rutinaExiste) {
            Rutina nuevaRutina = new Rutina();
            nuevaRutina.setDescripcion(descripcion);
            nuevaRutina.setDeporteId(deporteId);
            nuevaRutina.setTiempoDuracion(tiempoDuracion);
            nuevaRutina.setEstado(true);

            // Buscar la posiciÃ³n donde agregar la nueva rutina
            int i = 0;
            while (i < rutinas.length && rutinas[i] != null) {
                i++;
            }

            if (i < rutinas.length) {
                rutinas[i] = nuevaRutina;
            } else {
                System.out.println("No hay espacio suficiente para agregar la rutina.");
            }
        } else {
            if (!deporteExiste) {
                System.out.println("El deporte no existe.");
            }
            if (rutinaExiste) {
                System.out.println("La rutina ya estÃ¡ registrada.");
            }
        }
    }

    // Metodos para editar e inactivar informaciÃ³n en cada catÃ¡logo
    // ...
    // Metodo para inactivar un deporte
    public void inactivarDeporte(int deporteId) {
        boolean deporteExiste = false;
        boolean deporteEnRutina = false;
        Deporte deportes = null;
        for (Deporte d = deportes ) {
            if (d != null && d.getId() == deporteId) {
                deporteExiste = true;
                break;
            }
        }

        // Verificar si el deporte está asociado a alguna rutina
        for (int i = 0; i < rutina.length; i++) {
            Rutina r = rutina[i];
            if (r != null && r.getDeporteId() == deporteId) {
                deporteEnRutina = true;
                break;
            }
        }
    }
}
