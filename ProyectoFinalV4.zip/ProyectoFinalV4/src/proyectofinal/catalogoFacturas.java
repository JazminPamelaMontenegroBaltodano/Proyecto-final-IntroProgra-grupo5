package proyectofinal;

 import javax.swing.JOptionPane;
 import java.util.Arrays;

public class catalogoFacturas {
    
    private Factura regist[];
    private String[] valor_activo = {"Activa", "Anulada"};
    private catalogoRutinaDeporte rutinasDeporte;
    private catalogoDeportistas deportistas;
    
    public catalogoFacturas(){
        
    }
    
    public void menuFacturas(catalogoRutinaDeporte catalogo_rutinas, catalogoDeportistas catalogo_deportistas) {
        int opcionMenu = 0;
        String Op;
        
        rutinasDeporte=catalogo_rutinas;
        deportistas=catalogo_deportistas;
         
        while (opcionMenu !=4) {
                        
            Op = JOptionPane.showInputDialog("MENU FACTURA\nSELECCIONE UNA DE LAS OPCIONES\n"
            +"****************\n"
            +"1. REGISTRAR FACTURA\n"
            +"2. MOSTRAR FACTURAS\n"
            +"3. ANULAR FACTURA\n"        
            +"4. SALIR");
            
            // Valida la opcion seleccionada             
            if (Op==null){
                opcionMenu=4;  // Si es null es que presiono el boton Cancelar
            }else{
                opcionMenu = Integer.parseInt(Op); // Si fue un numero convierte de String a int
            }
            
            switch (opcionMenu) {
                case 1:
                    registrarFactura();
                    break;
                case 2:
                    consultaFactura();
                    break;
                case 3:
                    cambiar_estado();
                    break;
                case 4:
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opcion incorrecta, intente de nuevo.");
                    
            }
        }
    }
    
    public void registrarFactura() {
        
        int cantidad,cantidadrutinas;
        String Op;

      if (deportistas.lista_de_Deportistas() == null || rutinasDeporte.lista_de_Rutinas() == null ){
          JOptionPane.showMessageDialog(null,"No hay Deportistas o Rutinas aun, debe ingresar al menos un Deportista y una rutina para generar la Factura");
      }else{        
                
        do {
            // Se solicita cantidad de rutinas a ingresar
            Op=JOptionPane.showInputDialog(null,"Digite cuantas Facturas desea ingresar: ");
            
            
            if (Op!=null){
                cantidad=Integer.parseInt(Op);
            } else{
                cantidad=0; // Si presiona cancelar se mantiene preguntando por numero a ingresar
            }
                
        }while (cantidad==0);
                
        // Se inicializa arreglo de rutinas segun la cantidad rutinas escogidas en la opcion anterior
        regist = new Factura [cantidad];
        
        // Se hace ciclo de llenado para la cantidad de rutinas seleccionadas
        for(int x=0; x<cantidad;x++){
            Factura r=new Factura();
            
            String deportista;
            boolean salir=true;
            deportista=JOptionPane.showInputDialog(null,"Seleccione el Deportista a Facturar:","Selection", JOptionPane.DEFAULT_OPTION, null, deportistas.lista_de_Deportistas(),"").toString();

            do {
                // Se solicita cantidad de rutinas a ingresar
                Op=JOptionPane.showInputDialog(null,"Digite cuantas Rutinas desea facturar: ");

                if (Op!=null){
                    cantidadrutinas=Integer.parseInt(Op);
                } else{
                    cantidadrutinas=0; // Si presiona cancelar se mantiene preguntando por numero a ingresar
                }

            }while (cantidadrutinas==0);            
            
            String rutinasFacturar[]=new String[cantidadrutinas];
            for(int x2=0; x2<cantidadrutinas;x2++){
               rutinasFacturar[x2]=JOptionPane.showInputDialog(null,"Seleccione la Rutina "+x2,"Selection", JOptionPane.DEFAULT_OPTION, null, rutinasDeporte.lista_de_Rutinas(),"").toString(); 
            }
            
            r.registrarFactura(deportista, rutinasFacturar);
            
            regist[x]=r;           
        }        
        // Se termina insercion y se regresa a menu 
      }
    }
    
    public void consultaFactura(){
        
       String tira = "Facturas:\n";
        
        if (regist == null) { 
            JOptionPane.showMessageDialog(null,"No hay facturas registradas, utilice la opcion de insertar primero");
        }else{ 

            // Generacion de String con todas las rutinas a mostrar segun tamaño de arreglo
            for (int x = 0; x < regist.length;x++){
                  
            tira=tira + x +".Fact No." +regist[x].getIDFactura()+ " Deportista:" + regist[x].getnombreCliente() + " Rutinas:"+ Arrays.toString(regist[x].getrutinasFacturadas())+ " - Estado:" +
                    " "+ regist[x].getEstado() +"\n";
            }
            
            // Mostrando rutinas en dialogo
            JOptionPane.showMessageDialog(null,tira);
            
            // Regresando al menu
        }   
        
    }
       
    
    public void cambiar_estado(){
        String Op;
        String tira="";
        int opcion,posicion;
        rutinaDeporte r;
        
        // Valida que haya rutinas ingresadas
        if (regist == null) { 
            JOptionPane.showMessageDialog(null,"No hay Facturas ingresadas, utilice la opcion de insertar primero");
        }else{ 

           // Mostrando las rutinas para seleccionar la que se quiere modificar
           for (int x = 0; x < regist.length;x++){
                  
                tira=tira + x +".Fact No." +regist[x].getIDFactura()+ "-Deportista" + regist[x].getnombreCliente() + " - Estado:" +
                    " "+ regist[x].getEstado() +"\n";
            }
                       
            do {
                // Muestra las rutinas existentes para escoger la a modificar
                Op=JOptionPane.showInputDialog(null,"Seleccione la Factura a Cambiar Estado: \n"+tira);

                if (Op!=null){
                    posicion=Integer.parseInt(Op);
                } else{
                    posicion=-1; // Si presiona cancelar se mantiene preguntando por numero a ingresar
                }
                
            }while (posicion<0);
                
            if (regist[posicion].isEstado()) {
                regist[posicion].setEstado(false);
                JOptionPane.showMessageDialog(null,"Cambio realizado con Éxito \n Estado Anterior:" + valor_activo[1] +" - Nuevo Estado: " + valor_activo[0]);

            }else{
                regist[posicion].setEstado(true);
                JOptionPane.showMessageDialog(null,"Cambio realizado con Éxito \n Estado Anterior:" + valor_activo[0] +" - Nuevo Estado: " + valor_activo[1]);
            };                           
        }
    }
    
}