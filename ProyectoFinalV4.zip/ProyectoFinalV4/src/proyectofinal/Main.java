package proyectofinal;

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        catalogoUsuario usuarios = new catalogoUsuario();
        catalogoDeporte deportes = new catalogoDeporte();
        catalogoRutinaDeporte rutinaDeportes = new catalogoRutinaDeporte();
        catalogoDeportistas deportistas = new catalogoDeportistas();
        catalogoPadreFamilia padresFamilia = new catalogoPadreFamilia();
        catalogoFacturas facturas = new catalogoFacturas();

        int opcionMenu = 0;
        String Op;

        while (opcionMenu != 7) {
            Op = JOptionPane.showInputDialog("BIENVENIDO A LA ESCUELA DEPORTIVA CAZATALENTOS\nSELECCIONE UNA DE LAS OPCIONES\n"
                    + "********************************************\n"
                    + "1- CATALOGO DE USUARIOS\n"
                    + "2- CATALOGO DE DEPORTISTAS\n"
                    + "3- CATALOGO DE PADRES DE FAMILIA\n"
                    + "4- CATALOGO DE DEPORTES\n"
                    + "5- CATALOGO DE RUTINAS\n"
                    + "6- FACTURACION\n"
                    + "7- SALIR");
            
            // Valida la opcion seleccionada             
            if (Op==null){
                opcionMenu=7;  // Si es null es que presiono el boton Cancelar
            }else{
                opcionMenu = Integer.parseInt(Op); // Si fue un numero convierte de String a int
            }
            
            switch (opcionMenu) {
                case 1:
                    usuarios.MenuPrincipal();
                    break;
                case 2:
                    deportistas.menuDeportistas();
                    break;
                case 3:
                    padresFamilia.menuDeporte(deportistas);
                    break;
                case 4:
                    deportes.menuDeporte(rutinaDeportes);
                    break;
                case 5:
                    rutinaDeportes.menuRutinas(deportes);
                    break;
                case 6:
                    facturas.menuFacturas(rutinaDeportes, deportistas);
                    break;
                case 7: 
                    JOptionPane.showMessageDialog(null, "Saliendo del programa.");
                    System.exit(0);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "OpciOn no valida. Ingrese solo numeros del 1 al 5 e intentelo de nuevo.");
            }
        }
    }     
    
}
