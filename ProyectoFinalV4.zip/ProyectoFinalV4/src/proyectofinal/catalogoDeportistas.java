package proyectofinal;

import javax.swing.JOptionPane;

public class catalogoDeportistas {

    private Deportista regist[];
    private String[] valor_activo = {"Activo", "Inactivo"};
    
    public catalogoDeportistas(){
        
    }
    
    public void menuDeportistas() {
        
        String Op;
        int opcion;
      
        do{  
            Op=JOptionPane.showInputDialog(null," GESTION DE DEPORTISTAS\n\n"
                    + "1.AGREGAR DEPORTISTA \n"
                    + "2.VER DEPORTISTAS REGISTRADAS \n"
                    + "3.EDITAR DEPORTISTA\n"
                    + "4.ACTIVAS/DESACTIVAR\n"
                    + "5.SALIR");
            
            // Valida la opcion seleccionada             
            if (Op==null){
                opcion=5;  // Si es null es que presiono el boton Cancelar
            }else{
                opcion = Integer.parseInt(Op); // Si fue un numero convierte de String a int
            }
            
            switch(opcion){
                case 1:
                    insertar();
                    break;
                case 2:
                    consultar();
                    break;
                case 3:
                    modificar();
                    break;
                case 4:
                    cambiar_estado();
                    break;
                case 5:
                    break;
                    default:
                    JOptionPane.showMessageDialog(null,"Opcion incorrecta");
                    break;
                }
        }while (opcion!=5);

    }

    public void insertar(){
    
        int cantidad;
        String Op;
                
            do {
                // Se solicita cantidad de rutinas a ingresar
                Op=JOptionPane.showInputDialog(null,"Digite cuantos deportistas desea ingresar: ");

                if (Op!=null){
                    cantidad=Integer.parseInt(Op);
                } else{
                    cantidad=0; // Si presiona cancelar se mantiene preguntando por numero a ingresar
                }

            }while (cantidad==0);

            // Se inicializa arreglo de rutinas segun la cantidad rutinas escogidas en la opcion anterior
            regist = new Deportista [cantidad];

            // Se hace ciclo de llenado para la cantidad de rutinas seleccionadas
            for(int x=0; x<cantidad;x++){
                Deportista r=new Deportista ();
                
                String id_deportista;
                boolean salir=true;
                
                // Valida que el nombre de la rutina ingresa no haya sido ya ingresado/utilizado
                do{
                   id_deportista=JOptionPane.showInputDialog(null,"Digite el ID del deportista: ");
                   if (validar_identificacion_existe(id_deportista)){
                       JOptionPane.showMessageDialog(null,"Ese ID de Deportista ya existe, modifiquelo: ");
                   }else{
                       salir=false;
                   }
                }while (salir);
                r.setId(id_deportista);
                r.setNombre(JOptionPane.showInputDialog(null, "Digite el nombre del deportista:"));
                r.setApellidos(JOptionPane.showInputDialog(null, "Digite los apellidos del deportista:"));
                r.setCiudad(JOptionPane.showInputDialog(null, "Digite la ciudad del deportista:"));
                r.setDireccion(JOptionPane.showInputDialog(null, "Digite la direccion del deportista:"));
                r.setTelefono(JOptionPane.showInputDialog(null, "Digite el telefono del deportista:"));
                r.setCorreoElectronico(JOptionPane.showInputDialog(null, "Digite el correo electronico del deportista:"));                                   
                r.setEstado(JOptionPane.showInputDialog(null,"Digite el estado de la rutina activa o inactiva: ","Selection", JOptionPane.DEFAULT_OPTION, null, valor_activo, valor_activo[0]).toString().contains(valor_activo[0]));
                regist[x]=r;           
            }        
          // Se termina insercion y se regresa a menu        
    }
    
    public void consultar(){

        String tira = "Deportistas:\n";
        
        if (regist == null) { 
            JOptionPane.showMessageDialog(null,"No hay Deportistas ingresados, utilice la opcion de insertar primero");
        }else{ 

            // Generacion de String con todas las rutinas a mostrar segun tamaño de arreglo
            for (int x = 0; x < regist.length;x++){
                  
            tira=tira + x +"." +regist[x].getId()+ " - "+ regist[x].getNombre() +" " + regist[x].getApellidos() + " - Estado:" +
                    " "+regist[x].getEstado()+"\n";
            }
            
            // Mostrando rutinas en dialogo
            JOptionPane.showMessageDialog(null,tira);
            
            // Regresando al menu
        }                           
    }

    public String[] lista_de_Deportistas(){
        
        if (regist != null ){
            String[] tira=new String[regist.length];

            for (int x = 0; x < regist.length;x++){                  
                tira[x]=regist[x].getNombre()+" "+regist[x].getApellidos();
            }
            return tira;
        }else{
            return null;
        }    
    }
    
    public void modificar(){
        String Op;
        String tira="";
        int opcion,posicion;
        Deportista r;
        
        // Valida que haya rutinas ingresadas
        if (regist == null) { 
            JOptionPane.showMessageDialog(null,"No hay Deportistas ingresados, utilice la opcion de insertar primero");
        }else{ 

           // Mostrando las rutinas para seleccionar la que se quiere modificar
           for (int x = 0; x < regist.length;x++){
                  
            tira=tira + x +"." +regist[x].getId()+ "-Nombre:"+ regist[x].getNombre() +" " + regist[x].getApellidos() + " - Estado:" +
                    " "+regist[x].getEstado()+"\n";
            }
                       
            do {
                // Muestra las rutinas existentes para escoger la a modificar
                Op=JOptionPane.showInputDialog(null,"Seleccione el Deportista a modificar: \n"+tira);

                if (Op!=null){
                    posicion=Integer.parseInt(Op);
                } else{
                    posicion=-1; // Si presiona cancelar se mantiene preguntando por numero a ingresar
                }
                
            }while (posicion<0);
            
            r=new Deportista ();
            r.setNombre(JOptionPane.showInputDialog(null, "Digite el nombre del deportista:",regist[posicion].getNombre()));
            r.setApellidos(JOptionPane.showInputDialog(null, "Digite los apellidps del deportista:",regist[posicion].getApellidos()));
            r.setCiudad(JOptionPane.showInputDialog(null, "Digite la ciudad del deportista:",regist[posicion].getCiudad()));
            r.setDireccion(JOptionPane.showInputDialog(null, "Digite la direccion del deportista:",regist[posicion].getDireccion()));
            r.setTelefono(JOptionPane.showInputDialog(null, "Digite el telefono del deportista:",regist[posicion].getTelefono()));
            r.setCorreoElectronico(JOptionPane.showInputDialog(null, "Digite el correo electronico del deportista:",regist[posicion].getCorreoElectronico()));                                   
            r.setEstado(regist[posicion].isEstado());
            regist[posicion]=r;
        }
    }
    
    public void cambiar_estado(){
        String Op;
        String tira="";
        int opcion,posicion;
        rutinaDeporte r;
        
        // Valida que haya rutinas ingresadas
        if (regist == null) { 
            JOptionPane.showMessageDialog(null,"No hay Deportistas ingresados, utilice la opcion de insertar primero");
        }else{ 

           // Mostrando las rutinas para seleccionar la que se quiere modificar
           for (int x = 0; x < regist.length;x++){
                  
            tira=tira + x +"." +regist[x].getId()+ "-Nombre:"+ regist[x].getNombre() +" " + regist[x].getApellidos() + " - Estado:" +
                    " "+regist[x].getEstado()+"\n";
            }
                       
            do {
                // Muestra las rutinas existentes para escoger la a modificar
                Op=JOptionPane.showInputDialog(null,"Seleccione el Deportista a Cambiar Estado: \n"+tira);

                if (Op!=null){
                    posicion=Integer.parseInt(Op);
                } else{
                    posicion=-1; // Si presiona cancelar se mantiene preguntando por numero a ingresar
                }
                
            }while (posicion<0);
            
            if (regist[posicion].getEstado()==valor_activo[0]) {
                
                regist[posicion].setEstado(false);
                JOptionPane.showMessageDialog(null,"Cambio realizado con Éxito \n Estado Anterior:" + valor_activo[0] +" - Nuevo Estado: " + valor_activo[1]);
            }else{
                regist[posicion].setEstado(true);
                JOptionPane.showMessageDialog(null,"Cambio realizado con Éxito \n Estado Anterior:" + valor_activo[1] +" - Nuevo Estado: " + valor_activo[0]);
            }
                
        }
    }   
    
    public boolean validar_identificacion_existe(String identifica){

            boolean encontrado=false;
                   
            // Busca en el arreglo si el deporte esta siendo utilizado
            for (int x = 0; x < regist.length;x++){
               
                if (regist[x]!=null && regist[x].getId().equals(identifica)){
                  encontrado=true;
                }       
            }           
            return encontrado;
            
            // Regresando al menu                           
    }

  
}







