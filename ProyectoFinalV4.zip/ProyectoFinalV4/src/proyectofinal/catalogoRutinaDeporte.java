/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofinal;

import javax.swing.JOptionPane;

public class catalogoRutinaDeporte {
    
    private rutinaDeporte regist[];
    private String[] valor_activo = {"Activa", "Inactiva"};
    private catalogoDeporte deportes;
    
    public catalogoRutinaDeporte(){

        
    }
    
    public void menuRutinas(catalogoDeporte catalogo_deportes) {
        
      String Op;
      int opcion;
      deportes=catalogo_deportes;
      
        do{  
            Op=JOptionPane.showInputDialog(null," GESTION DE RUTINAS\n\n"
                    + "1.AGREGAR RUTINA \n"
                    + "2.VER RUTINAS REGISTRADAS \n"
                    + "3.EDITAR RUTINAS\n"
                    + "4.ACTIVAS/DESACTIVAR\n"
                    + "5.SALIR");
            
            // Valida la opcion seleccionada             
            if (Op==null){
                opcion=5;  // Si es null es que presiono el boton Cancelar
            }else{
                opcion = Integer.parseInt(Op); // Si fue un numero convierte de String a int
            }
            
            switch(opcion){
                case 1:
                    insertar();
                    break;
                case 2:
                    consultar();
                    break;
                case 3:
                    modificar();
                    break;
                case 4:
                    cambiar_estado();
                    break;
                case 5:
                    break;
                    default:
                    JOptionPane.showMessageDialog(null,"Opcion incorrecta");
                    break;
                }
        }while (opcion!=5);

    }
    
    public void insertar(){
    
        int cantidad;
        String Op;
        
        // Dado a que se requiere asociar deporte a rutina debe existir al menos un deporte
        if (deportes.lista_de_Deportes() == null) { 
            JOptionPane.showMessageDialog(null,"No hay deportes ingresados, debe ingresar almenos un deporte para poder ingresar rutinas");
        }else{ 
        
            do {
                // Se solicita cantidad de rutinas a ingresar
                Op=JOptionPane.showInputDialog(null,"Digite cuantas rutinas desea ingresar: ");


                if (Op!=null){
                    cantidad=Integer.parseInt(Op);
                } else{
                    cantidad=0; // Si presiona cancelar se mantiene preguntando por numero a ingresar
                }

            }while (cantidad==0);

            // Se inicializa arreglo de rutinas segun la cantidad rutinas escogidas en la opcion anterior
            regist = new rutinaDeporte [cantidad];

            // Se hace ciclo de llenado para la cantidad de rutinas seleccionadas
            for(int x=0; x<cantidad;x++){
                rutinaDeporte r=new rutinaDeporte ();
                
                String nombre_rutina;
                boolean salir=true;
                
                // Valida que el nombre de la rutina ingresa no haya sido ya ingresado/utilizado
                do{
                   nombre_rutina=JOptionPane.showInputDialog(null,"Digite el nombre de la rutina: ");
                   if (validar_nombre_rutina(nombre_rutina)){
                       JOptionPane.showMessageDialog(null,"Ese nombre de rutina ya existe, modifiquelo: ");
                   }else{
                       salir=false;
                   }
                }while (salir);
                        
                r.setDescripcion(nombre_rutina);
                r.setDeporte(JOptionPane.showInputDialog(null,"Seleccione el deporte al que corresponde la rutina: ","Selection", JOptionPane.DEFAULT_OPTION, null, deportes.lista_de_Deportes(), "").toString());
                r.setTiempoDuracion(JOptionPane.showInputDialog(null,"Digite el tiempo(min) de la rutina: "));
                r.setEstado(JOptionPane.showInputDialog(null,"Digite el estado de la rutina activa o inactiva: ","Selection", JOptionPane.DEFAULT_OPTION, null, valor_activo, valor_activo[0]).toString());
                regist[x]=r;           
            }        
          // Se termina insercion y se regresa a menu 
        }
    }
    
    public void consultar(){

        String tira = "Rutinas:\n";
        
        if (regist == null) { 
            JOptionPane.showMessageDialog(null,"No hay rutinas ingresadas, utilice la opcion de insertar primero");
        }else{ 

            // Generacion de String con todas las rutinas a mostrar segun tamaño de arreglo
            for (int x = 0; x < regist.length;x++){
                  
            tira=tira + x +"." +regist[x].getDescripcion()+ "-Deporte:"+ regist[x].getDeporte() +"- Duración:" + regist[x].getTiempoDuracion() + " - Estado:" +
                    " "+regist[x].getEstado()+"\n";
            }
            
            // Mostrando rutinas en dialogo
            JOptionPane.showMessageDialog(null,tira);
            
            // Regresando al menu
        }                           
    }
    
    public String[] lista_de_Rutinas(){
        
        if (regist != null ){
            String[] tira=new String[regist.length];

            for (int x = 0; x < regist.length;x++){                  
                tira[x]=regist[x].getDescripcion();
            }
            return tira;
        }else{
            return null;
        }    
    }
    
    public void modificar(){
        String Op;
        String tira="";
        int opcion,posicion;
        rutinaDeporte r;
        
        // Valida que haya rutinas ingresadas
        if (regist == null) { 
            JOptionPane.showMessageDialog(null,"No hay rutinas ingresadas, utilice la opcion de insertar primero");
        }else{ 

           // Mostrando las rutinas para seleccionar la que se quiere modificar
           for (int x = 0; x < regist.length;x++){
                  
            tira=tira + x +"." +regist[x].getDescripcion()+ "- Duración:" + regist[x].getTiempoDuracion() + " - Estado:" +
                    " "+regist[x].getEstado()+"\n";
            }
                       
            do {
                // Muestra las rutinas existentes para escoger la a modificar
                Op=JOptionPane.showInputDialog(null,"Seleccione la rutina a modificar: \n"+tira);

                if (Op!=null){
                    posicion=Integer.parseInt(Op);
                } else{
                    posicion=-1; // Si presiona cancelar se mantiene preguntando por numero a ingresar
                }
                
            }while (posicion<0);
            
            r=new rutinaDeporte ();
            r.setDescripcion(JOptionPane.showInputDialog(null,"Digite el nuevo nombre de la rutina: ",regist[posicion].getDescripcion()));
            r.setDeporte(JOptionPane.showInputDialog(null,"Seleccione el deporte al que corresponde la rutina: ","Selection", JOptionPane.DEFAULT_OPTION, null,deportes.lista_de_Deportes(),regist[posicion].getDeporte()).toString());
            r.setTiempoDuracion(JOptionPane.showInputDialog(null,"Digite el nuevo tiempo de la rutina: ",regist[posicion].getTiempoDuracion()));
            r.setEstado(regist[posicion].getEstado());
            regist[posicion]=r;        

        }
    }
    
    public void cambiar_estado(){
        String Op;
        String tira="";
        int opcion,posicion;
        rutinaDeporte r;
        
        // Valida que haya rutinas ingresadas
        if (regist == null) { 
            JOptionPane.showMessageDialog(null,"No hay rutinas ingresadas, utilice la opcion de insertar primero");
        }else{ 

           // Mostrando las rutinas para seleccionar la que se quiere modificar
           for (int x = 0; x < regist.length;x++){
                  
            tira=tira + x +"." +regist[x].getDescripcion()+ "- Duración:" + regist[x].getTiempoDuracion() + " - Estado:" +
                    " "+regist[x].getEstado()+"\n";
            }
                       
            do {
                // Muestra las rutinas existentes para escoger la a modificar
                Op=JOptionPane.showInputDialog(null,"Seleccione la rutina a Cambiar Estado: \n"+tira);

                if (Op!=null){
                    posicion=Integer.parseInt(Op);
                } else{
                    posicion=-1; // Si presiona cancelar se mantiene preguntando por numero a ingresar
                }
                
            }while (posicion<0);
            
            if (regist[posicion].getEstado()==valor_activo[0]) {
                
                regist[posicion].setEstado(valor_activo[1]);
                JOptionPane.showMessageDialog(null,"Cambio realizado con Éxito \n Estado Anterior:" + valor_activo[0] +" - Nuevo Estado: " + valor_activo[1]);
            }else{
                regist[posicion].setEstado(valor_activo[0]);
                JOptionPane.showMessageDialog(null,"Cambio realizado con Éxito \n Estado Anterior:" + valor_activo[1] +" - Nuevo Estado: " + valor_activo[0]);
            }
                
        }
    }

    public boolean validar_deporte_usado_rutinas(String nomDeporte){

            boolean encontrado=false;
                   
            // Busca en el arreglo si el deporte esta siendo utilizado
            for (int x = 0; x < regist.length;x++){
               
                if (regist[x]!=null && regist[x].getDeporte().equals(nomDeporte)){
                  encontrado=true;
                }       
            }           
            return encontrado;
            
            // Regresando al menu                           
    }
    
    public boolean validar_nombre_rutina(String nomRutina){

        boolean encontrado=false;
         
        // Busca en el arreglo si el deporte esta siendo utilizado
        for (int x = 0; x < regist.length;x++){

            if (regist[x]!=null && regist[x].getDescripcion().equals(nomRutina)){
              encontrado=true;
            }       
        }           
        return encontrado;            
        // Regresando al menu                           
    }
   
}