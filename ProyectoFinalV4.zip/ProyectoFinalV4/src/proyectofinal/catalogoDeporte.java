package proyectofinal;
import javax.swing.JOptionPane;
public class catalogoDeporte {
    
    private Deporte regist[];
    private String[] valor_activo = {"Activo", "Inactivo"};
    private catalogoRutinaDeporte rutinasDeporte;
    
    public catalogoDeporte(){
        
    }
    
    public void menuDeporte(catalogoRutinaDeporte catalogo_rutinas) {
        int opcionMenu = 0;
        String Op;
        
        rutinasDeporte=catalogo_rutinas;
         
        while (opcionMenu !=5) {
                        
            Op = JOptionPane.showInputDialog("MENU DEPORTE\nSELECCIONE UNA DE LAS OPCIONES\n"
            +"****************\n"
            +"1. REGISTRAR DEPORTE\n"
            +"2. MODIFICAR DEPORTE\n"
            +"3. CAMBIAR ESTADO DE DEPORTE\n"        
            +"4. VER DEPORTES REGISTRADOS\n"
            +"5. SALIR");
            
            // Valida la opcion seleccionada             
            if (Op==null){
                opcionMenu=5;  // Si es null es que presiono el boton Cancelar
            }else{
                opcionMenu = Integer.parseInt(Op); // Si fue un numero convierte de String a int
            }
            
            switch (opcionMenu) {
                case 1:
                    registrarDeporte();
                    break;
                case 2:
                    modificar();
                    break;
                case 3:
                    cambiar_estado();
                    break;
                case 4:
                    consultaDeporte();
                    break;
                case 5:
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opcion incorrecta, intente de nuevo.");
                    
            }
        }
    }
    
    public void registrarDeporte() {
        
        int cantidad;
        String Op;
        
        do {
            // Se solicita cantidad de rutinas a ingresar
            Op=JOptionPane.showInputDialog(null,"Digite cuantos Deportes desea ingresar: ");
            
            
            if (Op!=null){
                cantidad=Integer.parseInt(Op);
            } else{
                cantidad=0; // Si presiona cancelar se mantiene preguntando por numero a ingresar
            }
                
        }while (cantidad==0);
                
        // Se inicializa arreglo de rutinas segun la cantidad rutinas escogidas en la opcion anterior
        regist = new Deporte [cantidad];
        
        // Se hace ciclo de llenado para la cantidad de rutinas seleccionadas
        for(int x=0; x<cantidad;x++){
            Deporte r=new Deporte ();
            
            String nombreDepInput;
            boolean salir=true;
            
            // Valida si el nombre del deporte ya esta siendo utilizado
            do{
               nombreDepInput = JOptionPane.showInputDialog("Ingrese el nombre del deporte:"); 
               if (validar_nombre_deporte(nombreDepInput)){
                       JOptionPane.showMessageDialog(null,"Ese nombre de deporte ya existe, modifiquelo: ");
                   }else{
                       salir=false;
                   }
            }while (salir);
            
            r.setNombreDep(nombreDepInput);

            String caracteristicasInput = JOptionPane.showInputDialog("Ingrese una breve descripcion del deporte a registrar:");
            r.setCaracteristicas(caracteristicasInput);

            String estadoInput = JOptionPane.showInputDialog(null,"Ingrese el estado del deporte: ","Selection", JOptionPane.DEFAULT_OPTION, null, valor_activo, valor_activo[0]).toString();
            r.setEstado(estadoInput.equals(valor_activo[0]));
            
            regist[x]=r;           
        }        
        // Se termina insercion y se regresa a menu        
        
    }
    
    public void consultaDeporte(){
        
       String tira = "Deportes:\n";
        
        if (regist == null) { 
            JOptionPane.showMessageDialog(null,"No hay deportes registrados, utilice la opcion de insertar primero");
        }else{ 

            // Generacion de String con todas las rutinas a mostrar segun tamaño de arreglo
            for (int x = 0; x < regist.length;x++){
                  
            tira=tira + x +"." +regist[x].getNombreDep()+ "- Caracteristica del deporte:" + regist[x].getCaracteristicas() + " - Estado:" +
                    " "+ regist[x].getEstado() +"\n";
            }
            
            // Mostrando rutinas en dialogo
            JOptionPane.showMessageDialog(null,tira);
            
            // Regresando al menu
        }   
        
    }
    
    public String[] lista_de_Deportes(){
        
        if (regist != null ){
            String[] tira=new String[regist.length];

            for (int x = 0; x < regist.length;x++){                  
                tira[x]=regist[x].getNombreDep();
            }
            return tira;
        }else{
            return null;
        }    
    }
    
    public void modificar(){
        String Op;
        String tira="";
        int opcion,posicion;
        Deporte r;
        
        // Valida que haya rutinas ingresadas
        if (regist == null) { 
            JOptionPane.showMessageDialog(null,"No hay Deportes ingresados, utilice la opcion de insertar primero");
        }else{ 

           // Mostrando las rutinas para seleccionar la que se quiere modificar
           for (int x = 0; x < regist.length;x++){
                  
            tira=tira + x +"." +regist[x].getNombreDep()+ "- Caracteristica del deporte:" + regist[x].getCaracteristicas() + " - Estado:" +
                    " "+ regist[x].getEstado() +"\n";
            }
                       
            do {
                // Muestra las rutinas existentes para escoger la a modificar
                Op=JOptionPane.showInputDialog(null,"Seleccione el Deporte a modificar: \n"+tira);

                if (Op!=null){
                    posicion=Integer.parseInt(Op);
                } else{
                    posicion=-1; // Si presiona cancelar se mantiene preguntando por numero a ingresar
                }
                
            }while (posicion<0);
            
            r=new Deporte();
            r.setNombreDep(regist[posicion].getNombreDep());
            r.setCaracteristicas(JOptionPane.showInputDialog("Ingrese una breve descripcion del deporte a registrar:",regist[posicion].getCaracteristicas()));
            r.setEstado(regist[posicion].isEstado());
            regist[posicion]=r;
        }
    }    
    
    public void cambiar_estado(){
        String Op;
        String tira="";
        int opcion,posicion;
        rutinaDeporte r;
        
        // Valida que haya rutinas ingresadas
        if (regist == null) { 
            JOptionPane.showMessageDialog(null,"No hay deportes ingresados, utilice la opcion de insertar primero");
        }else{ 

           // Mostrando las rutinas para seleccionar la que se quiere modificar
           for (int x = 0; x < regist.length;x++){
                  
                tira=tira + x +"." +regist[x].getNombreDep()+ " - Estado:" +
                    " "+ regist[x].getEstado() +"\n";;
            }
                       
            do {
                // Muestra las rutinas existentes para escoger la a modificar
                Op=JOptionPane.showInputDialog(null,"Seleccione el deporte a Cambiar Estado: \n"+tira);

                if (Op!=null){
                    posicion=Integer.parseInt(Op);
                } else{
                    posicion=-1; // Si presiona cancelar se mantiene preguntando por numero a ingresar
                }
                
            }while (posicion<0);
                        
                if (regist[posicion].isEstado()) {                    
                    if (!rutinasDeporte.validar_deporte_usado_rutinas(regist[posicion].getNombreDep())) {
                        regist[posicion].desactivarDeporte();
                        JOptionPane.showMessageDialog(null,"Cambio realizado con Éxito \n Estado Anterior:" + valor_activo[0] +" - Nuevo Estado: " + valor_activo[1]);
                
                    }else{
                        JOptionPane.showMessageDialog(null,"El deporte no se puede inactivar debido a que esta siendo utilizado en 1 o mas rutinas"); 
                    }
                
                }else{
                    regist[posicion].activarDeporte();
                    JOptionPane.showMessageDialog(null,"Cambio realizado con Éxito \n Estado Anterior:" + valor_activo[1] +" - Nuevo Estado: " + valor_activo[0]);
                }
           
                
        }
    }
    
    public boolean validar_nombre_deporte(String nomDeporte){

        boolean encontrado=false;
        
        // Busca en el arreglo si el nombre del deporte esta siendo utilizado
        for (int x = 0; x < regist.length;x++){

            if (regist[x]!=null && regist[x].getNombreDep().equals(nomDeporte)){
              encontrado=true;
            }       
        }
        
        return encontrado;

        // Regresando al menu                           
    }
    
}