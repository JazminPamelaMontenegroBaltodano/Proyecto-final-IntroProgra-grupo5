package proyectofinal;

public class rutinaDeporte {

    private String descripcion;
    private String tiempoDuracion;
    private String estado;
    private String deporte;

    public rutinaDeporte() {
        this.descripcion = "";
        this.tiempoDuracion = "";
        this.estado = "";
        this.deporte = "";
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTiempoDuracion() {
        return tiempoDuracion;
    }
    
    public void setDeporte(String nomDeporte){
       deporte=nomDeporte;
    }
    
    public String getDeporte(){
       return deporte;
    }

    public void setTiempoDuracion(String tiempoDuracion) {
        this.tiempoDuracion = tiempoDuracion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
}   
