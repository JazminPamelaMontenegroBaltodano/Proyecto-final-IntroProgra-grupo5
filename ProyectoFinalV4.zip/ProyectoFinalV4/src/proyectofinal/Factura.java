package proyectofinal;
import javax.swing.JOptionPane;
import java.text.SimpleDateFormat;
import java.util.Date;
import proyectofinal.Deportista;

public class Factura {

    private String idFactura;
    private Date fechaHora;
    private String[] rutinasAsignadas;
    private String nombreCliente;
    private boolean anulada;

    public Factura() {
        this.idFactura = "";
        this.fechaHora = new Date();
        //this.nombreCliente = deportista.getNombre() + " " + deportista.getApellidos();
        //this.rutinasAsignadas = obtenerRutinasAsignadas(deportista);
        this.anulada = false;
    }
 
    public void registrarFactura(String deportista, String[] rutinas) {
        this.idFactura = generarIdFactura();
        this.fechaHora = new Date();
        this.nombreCliente =  deportista;
        this.rutinasAsignadas = rutinas;
        this.anulada = false;
   
    }
    
    private String generarIdFactura() {
        SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyyHHmmss");
        String timestamp = sdf.format(new Date());
        return timestamp;
    }


    public void mostrarFactura() {
        String mensaje = "FACTURA\n"
                + "ID: " + idFactura + "\n"
                + "Fecha y Hora: " + fechaHora + "\n"
                + "Cliente: " + nombreCliente + "\n"
                + rutinasAsignadas;

        if (anulada) {
            mensaje += "\nEstado: ANULADA";
        }

        JOptionPane.showMessageDialog(null, mensaje);
    }

    public void anularFactura() {
        if (!anulada) {
            anulada = true;
            System.out.println("La factura ha sido anulada.");
        } else {
            System.out.println("La factura ya está anulada.");
        }
    }
    
    public String getIDFactura(){
        return idFactura;
    }
    
    public String getnombreCliente(){
        return nombreCliente;
    }
    
    public String[] getrutinasFacturadas(){
        return rutinasAsignadas;
    } 
    
    public boolean isEstado(){
        return anulada;
    }
        
    public void setEstado(boolean estado){
        anulada=estado;
    }
    
    public String getEstado(){
        if (anulada)
            return "Anulada";
        else
            return "Activa";
    }
}
