package proyectofinal;

import javax.swing.JOptionPane;

public class PadreFamilia {

    private String nombre;
    private String apellidos;
    private String nombreNinoACargo;
    private String ciudad;
    private String direccion;
    private String telefono;
    private String correoElectronico;
    private boolean estado;

    public PadreFamilia() {
        this.nombre = "";
        this.apellidos = "";
        this.nombreNinoACargo = "";
        this.ciudad = "";
        this.direccion = "";
        this.telefono = "";
        this.correoElectronico = "";
        this.estado = true;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNombreNinoACargo() {
        return nombreNinoACargo;
    }

    public void setNombreNinoACargo(String nombreNinoACargo) {
        this.nombreNinoACargo = nombreNinoACargo;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public String getEstado(){
        if (estado)
            return "Activo";
        else
            return "Inactivo";
    }
    
}