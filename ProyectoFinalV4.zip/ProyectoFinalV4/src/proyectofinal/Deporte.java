package proyectofinal;
import javax.swing.JOptionPane;
public class Deporte {
    
    private String nombreDep;
    private String caracteristicas;
    private boolean estado;

    public Deporte() {
        this.nombreDep = "";
        this.caracteristicas = "";
        this.estado = true;
    }
    
    public void activarDeporte() {
        estado = true;
    }
    public void desactivarDeporte() {
        estado = false;    
    }

    public String getNombreDep() {
        return nombreDep;
    }

    public void setNombreDep(String nombreDep) {
        this.nombreDep = nombreDep;
    }

    public String getCaracteristicas() {
        return caracteristicas;
    }

    public void setCaracteristicas(String caracteristicas) {
        this.caracteristicas = caracteristicas;
    }

    public boolean isEstado() {
        return estado;
    }
    
    public String getEstado(){
        if (estado)
            return "Activo";
        else
            return "Inactivo";
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
   
}