package proyectofinal;

import javax.swing.JOptionPane;

public class catalogoPadreFamilia {

    private PadreFamilia regist[];
    private String[] valor_activo = {"Activo", "Inactivo"};  
    private catalogoDeportistas deportistas;

    public catalogoPadreFamilia() {
       
    }

    public void menuDeporte(catalogoDeportistas catalogo_deportistas) {
        int opcionMenu = 0;
        String Op;
        
        deportistas=catalogo_deportistas;
         
        while (opcionMenu !=5) {
                        
            Op = JOptionPane.showInputDialog("MENU PADRES DE FAMILIA\nSELECCIONE UNA DE LAS OPCIONES\n"
            +"****************\n"
            +"1. REGISTRAR PADRE DE FAMILIA\n"
            +"2. MODIFICAR PADRE DE FAMILIA\n"
            +"3. CAMBIAR ESTADO DE PADRE DE FAMILIA\n"        
            +"4. VER PADRES DE FAMILIA REGISTRADOS\n"
            +"5. SALIR");
            
            // Valida la opcion seleccionada             
            if (Op==null){
                opcionMenu=5;  // Si es null es que presiono el boton Cancelar
            }else{
                opcionMenu = Integer.parseInt(Op); // Si fue un numero convierte de String a int
            }
            
            switch (opcionMenu) {
                case 1:
                    registrarPadreFamilia();
                    break;
                case 2:
                    modificarPadreFamilia();
                    break;
                case 3:
                    cambiar_estadoPadreFamilia();
                    break;
                case 4:
                    consultaPadreFamilia();
                    break;
                case 5:
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opcion incorrecta, intente de nuevo.");
                    
            }
        }
    }
    
    public void registrarPadreFamilia() {
        
        int cantidad;
        String Op;
        
      if (deportistas.lista_de_Deportistas() == null ){
          JOptionPane.showMessageDialog(null,"No hay Deportistas aun, debe ingresar al menos un Deportista para asociarlo al Padre de familia");
      }else{
        do {
            // Se solicita cantidad de rutinas a ingresar
            Op=JOptionPane.showInputDialog(null,"Digite cuantos Padres de Familia desea ingresar: ");
            
            
            if (Op!=null){
                cantidad=Integer.parseInt(Op);
            } else{
                cantidad=0; // Si presiona cancelar se mantiene preguntando por numero a ingresar
            }
                
        }while (cantidad==0);
                
        // Se inicializa arreglo de rutinas segun la cantidad rutinas escogidas en la opcion anterior
        regist = new PadreFamilia [cantidad];
        
        // Se hace ciclo de llenado para la cantidad de rutinas seleccionadas
        for(int x=0; x<cantidad;x++){
            PadreFamilia r=new PadreFamilia ();
            
            String nombreDepInput;
            boolean salir=true;
                       
            r.setNombre(JOptionPane.showInputDialog(null, "Digite el nombre del padre:"));
            r.setApellidos(JOptionPane.showInputDialog(null, "Digite el apellido del padre:"));
            r.setNombreNinoACargo(JOptionPane.showInputDialog(null,"Digite el nombre del niño a cargo del padre:","Selection", JOptionPane.DEFAULT_OPTION, null, deportistas.lista_de_Deportistas(),"").toString());
            r.setCiudad(JOptionPane.showInputDialog(null, "Digite la ciudad del padre:")); 
            r.setDireccion(JOptionPane.showInputDialog(null, "Digite la direccion del padre:"));
            r.setTelefono(JOptionPane.showInputDialog(null, "Digite el telefono del padre:"));
            r.setCorreoElectronico(JOptionPane.showInputDialog(null, "Digite el correo electronico del padre:"));
            String estadoInput = JOptionPane.showInputDialog(null,"Ingrese el estado del deporte: ","Selection", JOptionPane.DEFAULT_OPTION, null, valor_activo, valor_activo[0]).toString();
            r.setEstado(estadoInput.equals(valor_activo[0]));
            
            regist[x]=r;           
        }        
        // Se termina insercion y se regresa a menu        
      }   
    }
    
    public void consultaPadreFamilia(){
        
       String tira = "Padres de Familia:\n";
        
        if (regist == null) { 
            JOptionPane.showMessageDialog(null,"No hay Padres registrados, utilice la opcion de insertar primero");
        }else{ 

            // Generacion de String con todas las rutinas a mostrar segun tamaño de arreglo
            for (int x = 0; x < regist.length;x++){
                  
            tira=tira + x +"." +regist[x].getNombre()+ " " + regist[x].getApellidos() + " - Estado:" +
                    " "+ regist[x].getEstado() +"\n";
            }
            
            // Mostrando rutinas en dialogo
            JOptionPane.showMessageDialog(null,tira);
            
            // Regresando al menu
        }   
        
    }
    
    
    public void modificarPadreFamilia(){
        String Op;
        String tira="";
        int opcion,posicion;
        PadreFamilia r;
        
        // Valida que haya rutinas ingresadas
        if (regist == null) { 
            JOptionPane.showMessageDialog(null,"No hay Padres ingresados, utilice la opcion de insertar primero");
        }else{ 

           // Mostrando las rutinas para seleccionar la que se quiere modificar
           for (int x = 0; x < regist.length;x++){
                  
            tira=tira + x +"." +regist[x].getNombre()+ " " + regist[x].getApellidos() + " - Estado:" +
                    " "+ regist[x].getEstado() +"\n";
            }
                       
            do {
                // Muestra las rutinas existentes para escoger la a modificar
                Op=JOptionPane.showInputDialog(null,"Seleccione el Padre a modificar: \n"+tira);

                if (Op!=null){
                    posicion=Integer.parseInt(Op);
                } else{
                    posicion=-1; // Si presiona cancelar se mantiene preguntando por numero a ingresar
                }
                
            }while (posicion<0);
            
            r=new PadreFamilia();
            r.setNombre(JOptionPane.showInputDialog(null, "Digite el nombre del padre:",regist[posicion].getNombre()));
            r.setApellidos(JOptionPane.showInputDialog(null, "Digite el apellido del padre:",regist[posicion].getApellidos()));
            r.setNombreNinoACargo(JOptionPane.showInputDialog(null,"Digite el nombre del niño a cargo del padre:","Selection", JOptionPane.DEFAULT_OPTION, null, deportistas.lista_de_Deportistas(),regist[posicion].getNombreNinoACargo()).toString());
            r.setCiudad(JOptionPane.showInputDialog(null, "Digite la ciudad del padre:",regist[posicion].getCiudad())); 
            r.setDireccion(JOptionPane.showInputDialog(null, "Digite la direccion del padre:",regist[posicion].getDireccion()));
            r.setTelefono(JOptionPane.showInputDialog(null, "Digite el telefono del padre:",regist[posicion].getTelefono()));
            r.setCorreoElectronico(JOptionPane.showInputDialog(null, "Digite el correo electronico del padre:",regist[posicion].getCorreoElectronico()));
            r.setEstado(regist[posicion].isEstado());
            regist[posicion]=r;
        }
    }    
    
    public void cambiar_estadoPadreFamilia(){
        String Op;
        String tira="";
        int opcion,posicion;
        rutinaDeporte r;
        
        // Valida que haya rutinas ingresadas
        if (regist == null) { 
            JOptionPane.showMessageDialog(null,"No hay Padres ingresados, utilice la opcion de insertar primero");
        }else{ 

           // Mostrando las rutinas para seleccionar la que se quiere modificar
           for (int x = 0; x < regist.length;x++){
                  
                tira=tira + x +"." +regist[x].getNombre()+ " " + regist[x].getApellidos() + " - Estado:" +
                    " "+ regist[x].getEstado() +"\n";
            }
                       
            do {
                // Muestra las rutinas existentes para escoger la a modificar
                Op=JOptionPane.showInputDialog(null,"Seleccione el Padre a Cambiar Estado: \n"+tira);

                if (Op!=null){
                    posicion=Integer.parseInt(Op);
                } else{
                    posicion=-1; // Si presiona cancelar se mantiene preguntando por numero a ingresar
                }
                
            }while (posicion<0);
                        
                if (regist[posicion].isEstado()) {                    
                    
                    regist[posicion].setEstado(false);
                    JOptionPane.showMessageDialog(null,"Cambio realizado con Éxito \n Estado Anterior:" + valor_activo[0] +" - Nuevo Estado: " + valor_activo[1]);              
                
                }else{
                    regist[posicion].setEstado(true);
                    JOptionPane.showMessageDialog(null,"Cambio realizado con Éxito \n Estado Anterior:" + valor_activo[1] +" - Nuevo Estado: " + valor_activo[0]);
                }           
                
        }
    }    
 
}